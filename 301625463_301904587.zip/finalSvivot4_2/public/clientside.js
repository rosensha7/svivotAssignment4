var app1 = angular.module('app1', ['ngRoute', 'ngCookies', 'LocalStorageModule', 'ngDialog'])
                  .service('sharedCurrUser', function () {
                        this.currUser = 'first';
                        this.user_logged_in = false;
                    });

app1.config(['$routeProvider', function($routeProvider){
    
    $routeProvider
    .when('/home', {
        templateUrl: 'guests.html',
        controller: 'guests_ctrl'
    })
    .when('/guests/login', {
        templateUrl: 'login.html',
        controller: 'login_ctrl'
    })
    .when('/guests/register', {
        templateUrl: 'register.html',
        controller: 'register_ctrl'
    })
    .when('/guests/forgotPassword', {
        templateUrl: 'forgotPassword.html',
        controller: 'forgotPassword_ctrl'
    })
    .when('/guests', {
        templateUrl: 'guests.html',
        controller: 'guests_ctrl' 
    })
    .when('/users', {
        templateUrl: 'users.html',
        controller: 'users_ctrl'
    })
    .when('/users/cart', {
        templateUrl: 'cart.html',
        controller: 'cart_ctrl'
    })
    .when('/users/allProducts', {
        templateUrl: 'users_allProducts.html',
        controller: 'allProducts_ctrl' 
    })
    .when('/guests/allProducts', {
        templateUrl: 'guests_allProducts.html',
        controller: 'allProducts_ctrl'
    })
    .when('/users/prevOrders', {
        templateUrl: 'users_orders.html',
        controller: 'prevOrders_ctrl'
    })
    .otherwise({ 
        redirectTo: '/home'
    });
}])

app1.controller('allProducts_ctrl', ['$scope', '$http','$location', '$routeParams','localStorageService', 'sharedCurrUser', 'ngDialog',function($scope, $http, $location, $routeParams, localStorageService, sharedCurrUser, ngDialog){
    
    $scope.usernameView = sharedCurrUser.currUser.Username;
    console.log("laastlogin " + sharedCurrUser.currUser.lastLoginDate);
    if(sharedCurrUser.currUser.lastLoginDate){
        $scope.lastLogView = sharedCurrUser.currUser.lastLoginDate.substring(0, 10);
    }
    
    $scope.getAllProducts = function(){
        $scope.prods_all = new Array();
        $http.get('http://localhost:3000/sortedProductsByCategory')
            .then(function(response){
            console.log(response.data);
            console.log(response.data[0]);
            $scope.products = Array.prototype.slice.call(response.data);
            console.log($scope.products);
                        }, function(error){console.log('PRINTED AN ERROR ' + error);})
    }
    
    $scope.modalDialog_all = function(ev) {
        $scope.dispProd_all = $scope.prods_all.filter(function(obj){return obj.pname == ev.target.value});
        console.log($scope.dispProd_all);
        ngDialog.open({
            template: 'dialog_all2',
            className: 'ngdialog-theme-default',
            scope: $scope,
            controller: 'allProducts_ctrl'
        });
    };
    
    $scope.setValue_all = function(product) {
         $scope.prods_all.push(product);
     }
    
    $scope.listHandler = function(){
        $scope.sortAttribute = 'pname';
        if($scope.sort_by == "by category"){
            $scope.sortAttribute = 'categoryname';
        }
        else if($scope.sort_by == "by price"){
            $scope.sortAttribute  = 'priceshekels';
        }
        else if($scope.sort_by == "by name"){
            $scope.sortAttribute  = 'pname';
        }
    }
    
    $scope.addItemToCart_all = function(ev){
        //$scope.itemToAdd_all = $scope.prods_all[ev.target.value-1];
        $scope.itemToAdd_all = $scope.prods_all.filter(function(obj){return obj.pname == ev.target.value})[0];
        console.log("itemToAdd - allprodsusers "+JSON.stringify($scope.itemToAdd_all));
        
        $http.get('http://localhost:3000/users/addItemToCart',
                 {params: {pid: $scope.itemToAdd_all.pid, cid: sharedCurrUser.currUser.ClientID, amount: 1, priceShekels: $scope.itemToAdd_all.priceshekels, priceDollars: $scope.itemToAdd_all.pricedollars}})
        .then(function(response){
            var serverResponse = response.data;//updates DB with a +1 amount for the item in the cart
            if(serverResponse == "amount increased"){//If item is already in the cart
                console.log("amount increased _ /allProd");
            }
            else{
                console.log("?should not be in else _ add _ hottest (LINE 109)");
            }
        })
    }
    
    $scope.addItemToCart_rec = function(ev){
        //$scope.itemToAdd_all = $scope.prods_all[ev.target.value-1];
        console.log("recProds -  "+JSON.stringify($scope.prods_rec));
        $scope.itemToAdd_rec = $scope.prods_rec.filter(function(obj){return obj.pName == ev.target.value})[0];
        console.log("itemToAdd - allprodsusers "+JSON.stringify($scope.itemToAdd_rec));
        
        $http.get('http://localhost:3000/users/addItemToCart',
                 {params: {pid: $scope.itemToAdd_rec.PID, cid: sharedCurrUser.currUser.ClientID, amount: 1, priceShekels: $scope.itemToAdd_rec.PriceShekels, priceDollars: $scope.itemToAdd_rec.PriceDollars}})
        .then(function(response){
            var serverResponse = response.data;//updates DB with a +1 amount for the item in the cart
            if(serverResponse == "amount increased"){//If item is already in the cart
                console.log("amount increased _ /allProdrec");
            }
            else{
                console.log("?should not be in else _ add _ recc (LINE 109)");
            }
        })
    }
    $scope.getRecommendedProducts = function(){
        $scope.prods_rec = new Array();
        $http.get('http://localhost:3000/users/recommendedProducts', {
            params: {categoryid: sharedCurrUser.currUser.CategoryID}
            })
            .then(function(response){
            $scope.user_logged_in = sharedCurrUser.user_logged_in;
            $scope.rec_products = Array.prototype.slice.call(response.data);
                        }, function(error){console.log('PRINTED AN ERROR ' + error);})
    }
    
    $scope.modalDialog_rec = function(ev) {
        $scope.dispProd_rec = $scope.prods_rec[ev.target.value-1];
        ngDialog.open({
            template: 'dialog_rec2',
            className: 'ngdialog-theme-default',
            scope: $scope,
            controller: 'allProducts_ctrl'
        });
    };
    
    $scope.setValue_rec = function(product) {
         $scope.prods_rec.push(product);
     }
    
    $scope.displayUsernameInPage = function(){
        try {
                console.log("curr user is "+sharedCurrUser.currUser.Username);
                $scope.usernameView = sharedCurrUser.currUser.Username;
            }
        catch(err) {
              console.log(err);
              $scope.usernameView = "none";
        }
    }
    
    $scope.getHottestProducts = function(){
        $scope.prods_hot = new Array();
        $http.get('http://localhost:3000/hottest')
            .then(function(response){
            console.log("RESPONSE.DATA = "+response.data);
            $scope.hottest_products = response.data;
            }, function(error){console.log('PRINTED AN ERROR ' + error);})
    }
    
    $scope.modalDialog_hot = function(ev) {
        console.log(ev.target)
        console.log(ev.target.value)
        $scope.dispProd_hot = $scope.prods_hot[ev.target.value-1];
        ngDialog.open({
            template: 'dialog_hot2',
            className: 'ngdialog-theme-default',
            scope: $scope,
            controller: 'allProducts_ctrl'
        });
    };
    
    $scope.setValue_hot = function(product) {
         $scope.prods_hot.push(product);
         $scope.btn_counter2 = $scope.btn_counter2+1;
     }
    
    $scope.aboutModal = function(){
         ngDialog.open({
            template: 'about.html'
        });
     }

}]);

app1.controller('guests_ctrl', ['$scope', '$http','$location', '$routeParams','localStorageService', 'sharedCurrUser', 'ngDialog',function($scope, $http, $location, $routeParams, localStorageService, sharedCurrUser, ngDialog){
    
    $scope.checkCookie = function(){
        console.log("in check cookie")
        if(localStorageService.keys().length > 0){
            var userInStorage = localStorageService.keys()[0];
            sharedCurrUser.currUser = localStorageService.get(userInStorage);
            sharedCurrUser.user_logged_in = true;
            $http.defaults.headers.common = {
                        'token': sharedCurrUser.currUser.token,
                        'username': sharedCurrUser.currUser.Username
                    };
            $location.path('/users').replace();
        }
        else{
            console.log("in hottest products!")
            $scope.getHottestProducts();
        }
    };

    $scope.getHottestProducts = function(){
        $scope.prods = new Array();
        $http.get('http://localhost:3000/hottest')
            .then(function(response){
            console.log(JSON.stringify(response.data));
            $scope.hottest_products = response.data;
            }, function(error){console.log('PRINTED AN ERROR ' + error);})
    }
    
    $scope.modalDialog = function(ev) {
        $scope.dispProd = $scope.prods[ev.target.value-1];
        ngDialog.open({
            template: 'dialog1',
            className: 'ngdialog-theme-default',
            scope: $scope,
            controller: 'guests_ctrl'
        });
    };
    
     $scope.setValue = function(product) {
         $scope.prods.push(product);
     }
     
     $scope.aboutModal = function(){
         ngDialog.open({
            template: 'about.html'
        });
     }
    
}]);

app1.controller('users_ctrl', ['$scope', '$http','$location', '$routeParams','localStorageService', 'sharedCurrUser', 'ngDialog',function($scope, $http, $location, $routeParams, localStorageService, sharedCurrUser, ngDialog){
    
    $scope.logOut = function(){
        sharedCurrUser.currUser= 'first';
        sharedCurrUser.user_logged_in = false;
        localStorageService.clearAll();
        $location.path('/guests').replace();
    }
    
    $scope.getHottestProducts = function(){
        
        if(!sharedCurrUser.currUser || sharedCurrUser.currUser == 'first'){
            $location.path('/guests').replace();
            return;
        }
        
        $scope.hot_prods = new Array();
        $http.get('http://localhost:3000/hottest')
            .then(function(response){
            sharedCurrUser.user_logged_in = true;
            console.log(response.data);
            try {
                $scope.usernameView = sharedCurrUser.currUser.Username;
                $scope.lastLogView = sharedCurrUser.currUser.lastLoginDate.substring(0, 10);
            }
            catch(err) {
                $scope.usernameView = "Guest";
            }
            $scope.hottest_products = response.data;
            }, function(error){console.log('PRINTED AN ERROR ' + error);})
    }
    
    $scope.getNewestProducts = function(){
        if(!sharedCurrUser.currUser || sharedCurrUser.currUser == 'first'){
            return;
        }
        $scope.new_prods = new Array();
        $http.get('http://localhost:3000/users')
            .then(function(response){
            console.log("NEWEST PRODUCTS: "+JSON.stringify(response.data));
            $scope.newest_products = response.data;
            }, function(error){console.log('PRINTED AN ERROR ' + error);})
    }
    
    $scope.modalDialog_hot = function(ev) {
        console.log(ev.target)
        console.log(ev.target.value)
        $scope.dispProd_hot = $scope.hot_prods[ev.target.value-1];
        ngDialog.open({
            template: 'dialog_users_hottest',
            className: 'ngdialog-theme-default',
            scope: $scope,
            controller: 'users_ctrl'
        });
    };
    
     $scope.setValue_hot = function(product) {
         $scope.hot_prods.push(product);
     }
     
     $scope.addItemToCart_hottest = function(ev){
        $scope.itemToAdd_hottest = $scope.hottest_products[ev.target.value-1];
        console.log("itemToAdd - "+JSON.stringify($scope.itemToAdd_hottest));//check pid or PID...
        
        $http.get('http://localhost:3000/users/addItemToCart',
                 {params: {pid: $scope.itemToAdd_hottest.PID, cid: sharedCurrUser.currUser.ClientID, amount: 1, priceShekels: $scope.itemToAdd_hottest.PriceShekels, priceDollars: $scope.itemToAdd_hottest.PriceDollars}})
        .then(function(response){
            var serverResponse = response.data;//updates DB with a +1 amount for the item in the cart
            if(serverResponse == "amount increased"){//If item is already in the cart
                console.log("amount increased _ /users");
            }
            else{
                console.log("?should not be in else _ add _ hottest (LINE 311)");
            }
        })
    }
     
     //////////////////////////////////////////////////showDetails_new_btn_users
     
     $scope.addItemToCart_newest = function(ev){
        $scope.itemToAdd_newest = $scope.newest_products[ev.target.value-1];
        console.log("itemToAdd - NEWEST"+JSON.stringify($scope.itemToAdd_newest));//check pid or PID...
        
        $http.get('http://localhost:3000/users/addItemToCart',
                 {params: {pid: $scope.itemToAdd_newest.PID, cid: sharedCurrUser.currUser.ClientID, amount: 1, priceShekels: $scope.itemToAdd_newest.PriceShekels, priceDollars: $scope.itemToAdd_newest.PriceDollars}})
        .then(function(response){
            var serverResponse = response.data;//updates DB with a +1 amount for the item in the cart
            if(serverResponse == "amount increased"){//If item is already in the cart
                console.log("amount increased _ /users");
            }
            else{
                console.log("?should not be in else _ add _ newest (LINE 328)");
            }
        })
    }
     
     $scope.modalDialog_new = function(ev) {
        $scope.dispProd_new = $scope.new_prods[ev.target.value-1];
        ngDialog.open({
            template: 'dialog_users_newest',
            className: 'ngdialog-theme-default',
            scope: $scope,
            controller: 'users_ctrl'
        });
    };
    
     $scope.setValue_new = function(product) {
         $scope.new_prods.push(product);
     }
     
     $scope.aboutModal = function(){
         ngDialog.open({
            template: 'about.html'
        });
     }
}]);

app1.controller('login_ctrl', ['$scope', '$http','$location', '$routeParams','localStorageService', 'sharedCurrUser', 'ngDialog',function($scope, $http, $location, $routeParams, localStorageService, sharedCurrUser, ngDialog){
    
    $scope.wrong_details_alert = "";
    
    $scope.checkCookie = function(){
        if(localStorageService.keys().length > 0){
            var userInStorage = localStorageService.keys()[0];
            sharedCurrUser.currUser = localStorageService.get(userInStorage);
            sharedCurrUser.user_logged_in = true;
            $http.defaults.headers.common = {
                        'token': sharedCurrUser.currUser.token,
                        'username': sharedCurrUser.currUser.Username
                    };
            $location.path('/users').replace();
        }
    };
    
    $scope.validateUser = function(){
        var today = new Date();
        var dd = today.getDate();
        var mm = today.getMonth()+1; //January is 0!
        var yyyy = today.getFullYear();
        if(dd<10) {
            dd = '0'+dd;
        } 
        if(mm<10) {
            mm = '0'+mm;
        } 
        today = mm + '/' + dd + '/' + yyyy;
        
        $http.post('http://localhost:3000/guests/login', {"username": $scope.loggingUser.username, "password": $scope.loggingUser.password, "lastlogindate": today})
            .then(function(response2){
                $scope.server_response = response2.data;
                if($scope.server_response != false){//if all is correct
                    //save user details to cookies and set him as currUser
                    console.log("un: " + $scope.server_response[0].Username);
                    localStorageService.clearAll();
                    console.log(localStorageService.set($scope.server_response[0].Username, $scope.server_response[0]));
                    sharedCurrUser.currUser = $scope.server_response[0];
                    //localStorageService.get($scope.server_response[0].Username);
                    $http.defaults.headers.common = {
                        'token': $scope.server_response[0].token,
                        'username': $scope.server_response[0].Username
                    };
                    $location.path('/users').replace();
                }
                else{//wrong details were entered
                    $scope.wrong_details_alert = "The details you have entered do not match our data.";
                }
            }, function(error){
                console.log('PRINTED AN ERROR ' + error);
        })
    }
    
    $scope.aboutModal = function(){
         ngDialog.open({
            template: 'about.html'
        });
     }
    
}]);

app1.controller('register_ctrl', ['$scope', '$http','$location', '$routeParams','localStorageService', 'sharedCurrUser', 'ngDialog',function($scope, $http, $location, $routeParams, localStorageService, sharedCurrUser, ngDialog){
    $scope.wrong_details_alert = "";
    
    $scope.getCountryList = function(){
        $http.get('http://localhost:3000/guests/getCountries')
        .then(function(response){
            console.log(response.data);
            $scope.countries = Array.prototype.slice.call(response.data);
        })
    }
    
    $scope.addUser = function(){
        console.log($scope.registeringUser.selectedCountry)
        var today = new Date();
        var dd = today.getDate();
        var mm = today.getMonth()+1; //January is 0!
        var yyyy = today.getFullYear();

        if(dd<10){
            dd = '0'+dd;
        } 
        if(mm<10){
            mm = '0'+mm;
        } 
        today = mm + '/' + dd + '/' + yyyy;
        
        console.log($scope.registeringUser.favCategory);
        $scope.favCat = 1;
        if($scope.registeringUser.favCategory == "Boots"){
            $scope.favCat = 2;
        }
        else if($scope.registeringUser.favCategory =="Sneakers"){
            $scope.favCat = 3;
        }
        else if($scope.registeringUser.favCategory == "Slippers"){
            $scope.favCat = 4;
        }
        
        $http.post('http://localhost:3000/guests/register', {
            "username": $scope.registeringUser.username,
            "password": $scope.registeringUser.password,
            "firstname": $scope.registeringUser.firstname,
            "lastname": $scope.registeringUser.lastname,
            "address": $scope.registeringUser.address,
            "lastlogindate": today,
            "country": $scope.registeringUser.selectedCountry,
            "q1": $scope.registeringUser.q1,
            "a1": $scope.registeringUser.a1,
            "favcategoryid": $scope.favCat
            })
            .then(function(response){
                console.log(response.data);
                $scope.server_response = response.data;
                if($scope.server_response == true){
                    $location.path('/guests/login').replace();
                }
                else{//wrong details were entered
                    $scope.wrong_details_alert = "Please enter valid details."
                }
            }, function(error){
                console.log('PRINTED AN ERROR ' + error);
        })
    }
    
    $scope.aboutModal = function(){
         ngDialog.open({
            template: 'about.html'
        });
     }
}]);

app1.controller('forgotPassword_ctrl', ['$scope', '$http','$location', '$routeParams','localStorageService', 'sharedCurrUser', 'ngDialog',function($scope, $http, $location, $routeParams, localStorageService, sharedCurrUser, ngDialog){
    $scope.answer_alert = "";
    $scope.showRedirectButton = false;
    
    $scope.retrieveQuestion = function(){
        console.log("isdghfusgf")
        $http.post('http://localhost:3000/getUserByUsername', {
            "username": $scope.senileUser.username
            })
            .then(function(response){
                console.log("res " + response.data[0]);
                $scope.server_response1 = response.data;
                if($scope.server_response1 == false){
                    console.log('something wrong in server...');
                    $scope.question = "No such user." 
                }
                else{
                    $scope.question = " " + $scope.server_response1[0].Q1;
                }
            }, function(error){
                console.log('PRINTED AN ERROR ' + error);
        })
    }
    
    $scope.questionUser = function(){
        $http.get('http://localhost:3000/forgotPassword', {
            params: {username: $scope.senileUser.username}
            })
            .then(function(response){
                console.log(response.data[0]);
                $scope.server_response2 = response.data;
                if($scope.server_response2 == false){
                    console.log('something wrong in server...');
                    $scope.answer_alert = "Wrong answer.";
                    $scope.showRedirectButton = false;
                }
                else if($scope.server_response2[0].A1 == $scope.senileUser.a1){//answer is correct
                    $scope.answer_alert = "Your password is: " + $scope.server_response2[0].Password;
                    $scope.showRedirectButton = true;
                }
                else{//wrong answer
                     $scope.answer_alert = "Wrong answer.";
                     $scope.showRedirectButton = false;
                }
            }, function(error){
                console.log('PRINTED AN ERROR ' + error);
        })
    }
    
    $scope.redirectToLogin = function(){
        $location.path('/guests/login').replace();
    }
    
    $scope.aboutModal = function(){
         ngDialog.open({
            template: 'about.html'
        });
     }
    
}]);

app1.controller('cart_ctrl', ['$scope', '$http','$location', '$routeParams','localStorageService', 'sharedCurrUser', 'ngDialog',function($scope, $http, $location, $routeParams, localStorageService, sharedCurrUser, ngDialog){
    
    $scope.init_prods_cart = function(){
        $scope.prods_cart = new Array();
    }
    
    $scope.prods_cart_length = function(){
        return prods_cart.length > 0;
    }
    
    $scope.logOut = function(){
        sharedCurrUser.currUser= 'first';
        sharedCurrUser.user_logged_in = false;
        localStorageService.clearAll();
        $location.path('/guests').replace();
    }
    
    $scope.getCartContent = function(){
        if(!sharedCurrUser.currUser || sharedCurrUser.currUser == 'first'){
            console.log(!sharedCurrUser.currUser);
            $location.path('/guests').replace();
            return;
        }
        $scope.usernameView = sharedCurrUser.currUser.Username;
        $scope.lastLogView = sharedCurrUser.currUser.lastLoginDate.substring(0, 10);
        $http.get('http://localhost:3000/users/showCartSortedpName', {
            params: {cid: sharedCurrUser.currUser.ClientID}
        })
        .then(function(response){//get list of products in cart
            //gets list of products from server
            if(response.data == "no items"){
                //cart is empty.
            }
            else{
                $scope.cartProducts = Array.prototype.slice.call(response.data);

                console.log("CART PRODUCTS - " + JSON.stringify($scope.cartProducts));

                $scope.sumTotalShekels = 0;
                $scope.sumTotalDollars = 0;

                //sums prices of product list
                $scope.cartProducts.forEach(function (prod) {
                    $scope.sumTotalShekels += prod.priceshekels * prod.amount;
                    $scope.sumTotalDollars += prod.pricedollars * prod.amount;
                })
            }
        })
    }
    
    $scope.decreaseAmount = function(ev){
        
        $scope.itemToRemove = $scope.cartProducts.filter(function(obj){return obj.pname == ev.target.value})[0];//gets the item to remove from list
        
        $http.get('http://localhost:3000/users/removeItemFromCart',
                 {params: {pid: $scope.itemToRemove.pid, cid: sharedCurrUser.currUser.ClientID, amount: 1, priceShekels: $scope.itemToRemove.priceshekels, priceDollars: $scope.itemToRemove.pricedollars}})
        .then(function(response){
            var serverResponse = response.data;//updates the DB and decreases the item amount in it
            if(serverResponse == "amount decreased"){
                $scope.sumTotalShekels -= $scope.itemToRemove.priceshekels*$scope.itemToRemove.amount;
                $scope.sumTotalDollars -= $scope.itemToRemove.pricedollars*$scope.itemToRemove.amount;
                
                $scope.itemToRemove.amount--;//NOT SURE IF UPDATES THE ARRAY AS WELL//updates the amount of the item
                
                $scope.sumTotalShekels += $scope.itemToRemove.priceshekels*$scope.itemToRemove.amount;
                $scope.sumTotalDollars += $scope.itemToRemove.pricedollars*$scope.itemToRemove.amount;
            }
            else if (serverResponse == "product removed"){//completely remove product from array
                $scope.sumTotalShekels -= $scope.itemToRemove.priceshekels*$scope.itemToRemove.amount;
                $scope.sumTotalDollars -= $scope.itemToRemove.pricedollars*$scope.itemToRemove.amount;
                
                $scope.itemToRemove.amount = 0;
                
                $scope.sumTotalShekels += $scope.itemToRemove.priceshekels*$scope.itemToRemove.amount;
                $scope.sumTotalDollars += $scope.itemToRemove.pricedollars*$scope.itemToRemove.amount;
                var indexOf_item_to_remove = $scope.cartProducts.findIndex(i => i.pname == $scope.itemToRemove.pname);
                $scope.cartProducts.splice(indexOf_item_to_remove, 1);
            }
            else{
                console.log("should not be in else - LINE 571");
            }
        })
    }
    
        $scope.increaseAmount = function(ev){
        $scope.itemToAdd = $scope.cartProducts.filter(function(obj){return obj.pname == ev.target.value})[0];
        console.log("itemToAdd - "+JSON.stringify($scope.itemToAdd));
        
        $http.get('http://localhost:3000/users/addItemToCart',
                 {params: {pid: $scope.itemToAdd.pid, cid: sharedCurrUser.currUser.ClientID, amount: 1, priceShekels: $scope.itemToAdd.priceshekels, priceDollars: $scope.itemToAdd.pricedollars}})
        .then(function(response){
            var serverResponse = response.data;//updates DB with a +1 amount for the item in the cart
            if(serverResponse == "amount increased"){//If item is already in the cart
                $scope.sumTotalShekels -= $scope.itemToAdd.priceshekels*$scope.itemToAdd.amount;
                $scope.sumTotalDollars -= $scope.itemToAdd.pricedollars*$scope.itemToAdd.amount;
                
                $scope.itemToAdd.amount++;
                
                $scope.sumTotalShekels += $scope.itemToAdd.priceshekels*$scope.itemToAdd.amount;
                $scope.sumTotalDollars += $scope.itemToAdd.pricedollars*$scope.itemToAdd.amount;
            }
            else{
                console.log("should not be in else _ add (LINE 594)");
            }
        })
    }
        
    $scope.setValue_cart = function(product_in_cart){
        $scope.prods_cart.push(product_in_cart);
    }
    
    $scope.modalDialog_cart = function(ev) {
        //console.log(ev.target);
        console.log("item to display: "+ ev.target.value);
        //$scope.dispProds_cart = $scope.prods_cart[ev.target.value-1];
        $scope.itemToDisplay = $scope.cartProducts.filter(function(obj){return obj.pname == ev.target.value})[0];
        console.log("item to display(again): "+$scope.itemToDisplay);
        ngDialog.open({
            template: 'dialog_cart',
            className: 'ngdialog-theme-default',
            scope: $scope,
            controller: 'cart_ctrl'
        });
    };
    
    $scope.aboutModal = function(){
         ngDialog.open({
            template: 'about.html'
        });
     }
    
    $scope.listHandler = function(){
        $scope.sortAttribute = 'pname';
        if($scope.sort_by == "by price"){
            $scope.sortAttribute  = 'priceshekels';
        }
        else if($scope.sort_by == "by name"){
            $scope.sortAttribute  = 'pname';
        }
    }
    
}]);
